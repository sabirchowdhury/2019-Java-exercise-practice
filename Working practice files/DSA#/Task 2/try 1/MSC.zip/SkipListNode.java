class SkipListNode {
    public String element;
    public SkipListNode[] next;


    public SkipListNode(String s, SkipListNode[] d) {
        element = s;
        next = d;

    }

}

